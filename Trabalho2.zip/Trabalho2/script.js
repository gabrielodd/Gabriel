$(function () {
    $('[data-toggle="tooltip"]').tooltip({ boundary: 'window' });
    $('[data-toggle="popover"]').popover();
 
    document.querySelector("#id-form").addEventListener("submit", function(e) { tudoValidoFunction(e) }, false)
 });
 
 function tudoValidoFunction(e) {
    e.preventDefault()
 
    let nome_valido = nomeValidoFunction()
    let sobrenome_valido = sobrenomeValidoFunction()
    let sexo_valido = sexoValidoFunction()
    let cidade_valido = cidadeValidoFunction()
    let estado_valido = estadoValidoFunction()
    let endereco_valido = enderecoValidoFunction()
    let email_valido = emailValidoFunction()
    let senha_valido = senhaValidoFunction()
 
    if (nome_valido && sobrenome_valido && sexo_valido && cidade_valido && estado_valido && endereco_valido && email_valido && senha_valido) {
       alert("Cadastro feito com sucesso")
    }
    else {
       alert("Não foi possivel o cadastro, tente novamente")
    }
 }
 
function nomeValidoFunction() {
    let nome = document.querySelector("#nome")
 
    if (nome.value === '') {
       nome.classList.add("is-invalid")
       nome.classList.remove("is-valid")
       return false
    }
    else {
       nome.classList.remove("is-invalid")
       nome.classList.add("is-valid")
       return true
    }
 }

 function sobrenomeValidoFunction() {
    let sobrenome = document.querySelector("#sobrenome")
 
    if (sobrenome.value === '') {
       sobrenome.classList.add("is-invalid")
       sobrenome.classList.remove("is-valid")
       return false
    }
    else {
       sobrenome.classList.remove("is-invalid")
       sobrenome.classList.add("is-valid")
       return true
    }
 }

 function cidadeValidoFunction() {
    let cidade = document.querySelector("#cidade")
 
    if (cidade.value === '') {
        cidade.classList.add("is-invalid")
        cidade.classList.remove("is-valid")
       return false
    }
    else {
        cidade.classList.remove("is-invalid")
        cidade.classList.add("is-valid")
       return true
    }
 }

 function estadoValidoFunction() {
    let estado = document.querySelector("#estado")
 
    if (estado.value === '0') {
        estado.classList.add("is-invalid")
        estado.classList.remove("is-valid")
       return false
    }
    else {
        estado.classList.remove("is-invalid")
        estado.classList.add("is-valid")
       return true
    }
 }

 function enderecoValidoFunction() {
    let endereco = document.querySelector("#endereco")
 
    if (endereco.value === '') {
        endereco.classList.add("is-invalid")
        endereco.classList.remove("is-valid")
       return false
    }
    else {
        endereco.classList.remove("is-invalid")
        endereco.classList.add("is-valid")
       return true
    }
 }
 function emailValidoFunction() {
    let email = document.querySelector("#email")
 
    if (email.value === '') {
        email.classList.add("is-invalid")
        email.classList.remove("is-valid")
       return false
    }
    else {
        email.classList.remove("is-invalid")
        email.classList.add("is-valid")
       return true
    }
 }

 function senhaValidoFunction() {
    let senha = document.querySelector("#senha")
 
    if (senha.value.length < 4) {
       senha.classList.add("is-invalid")
       senha.classList.remove("is-valid")
       return false
    }
    else {
       senha.classList.remove("is-invalid")
       senha.classList.add("is-valid")
       return true
    }
 }
 function sexoValidoFunction() {
    let sexo_masc = document.querySelector("#masc")
    let sexo_fem = document.querySelector("#fem")
    let outro = document.querySelector("#outro")
    let sexo_feedback = document.querySelector("#sexo-feedback")
 
    let botoes = document.querySelectorAll("input[name='sexoRadios']:checked")
    if (botoes.length === 0) {
       sexo_masc.classList.add("is-invalid")
       sexo_masc.classList.remove("is-valid")
       sexo_fem.classList.add("is-invalid")
       sexo_fem.classList.remove("is-valid")
       outro.classList.add("is-invalid")
       outro.classList.remove("is-valid")
       sexo_feedback.classList.add("d-block")
       return false
    }
    else {
       sexo_masc.classList.remove("is-invalid")
       sexo_masc.classList.add("is-valid")
       sexo_fem.classList.remove("is-invalid")
       sexo_fem.classList.add("is-valid")
       outro.classList.remove("is-invalid")
       outro.classList.add("is-valid")
       sexo_feedback.classList.remove("d-block")
       return true
    }
 }

 