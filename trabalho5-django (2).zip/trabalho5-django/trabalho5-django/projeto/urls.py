from django.urls import path
from django.conf.urls import include
from django.contrib import admin

urlpatterns = [
    path('', views.index, name='index'),
    path('admin/', admin.site.urls),
    path('produto/', include('produto.urls')),
    path('autenticacao/', include('autenticacao.urls')),
]
