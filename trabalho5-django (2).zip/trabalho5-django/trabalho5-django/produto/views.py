from django.shortcuts import render, redirect, get_object_or_404
from django.messages import
from django.contrib import messages
from datetime import datetime, timedelta
from django.views.decorators.http import require_POST
from django.core.paginator import Paginator
from django.contrib.auth.decorators import login_required
from django.db.models import Sum, F, FloatField 
from .models import Categoria, Produto, Tamanho, Preco
from produto.forms import ProdutoForm, RemoveProdutoForm, PesquisaProdutoForm

def lista_produtos(request, slug_da_categoria=None, slug_do_tamanho=None, slug_do_preco=None):
   categoria = None
   tamanho = None
   preco = None
   categorias = Categoria.objects.all().order_by("nome")
   tamanhos = Tamanho.objects.all().order_by("id")
   precos = Preco.objects.all().order_by("id")
   produtos = Produto.objects.filter(disponivel=True).order_by("nome")
   if slug_da_categoria:
      categoria = get_object_or_404(Categoria, slug=slug_da_categoria)
      produtos = produtos.filter(categoria_id=categoria).order_by("nome")

   if slug_do_tamanho: 
      tamanho = get_object_or_404(Tamanho, slug=slug_do_tamanho)
      produtos = produtos.filter(tamanho_id=tamanho).order_by("nome")

   if slug_do_preco:
      preco = get_object_or_404(Preco, slug=slug_do_preco)
      produtos = produtos.filter(preco_id=preco).order_by("nome")

   return render(request, 'produto/lista.html', {'categorias': categorias,
                                                 'tamanhos': tamanhos,
                                                 'precos' : precos,
                                                 'produtos': produtos,
                                                 'categoria': categoria,
                                                 'tamanho': tamanho,
                                                 'preco': preco,
                                                 })
def def lista_produto_pag(request):
   form = PesquisaProdutoForm(request.GET)
   if (form.is_valid()):
      busca_por = form.cleaned_data['busca_por']
      lista_de_produtos = Produto.objects.filter(nome__icontains=busca_por).order_by('nome')

      resultado = lista_de_produtos.aggregate(
          total=Sum(F('preco'), output_field=FloatField()))
      
      if resultado['total']:
         total = '{0:.2f}'.format(resultado['total'])
      else:
         total = '0,00'

      paginator = Paginator(lista_de_produtos, 5)
      pagina = request.GET.get('pagina')
      produtos = paginator.get_page(pagina)

#      lista_de_forms = []
#      for produto in produtos:
#         lista_de_forms.append(RemoveProdutoForm(initial={'produto_id': produto.id}))

      lista_de_ids = []
      for produto in produtos:
         lista_de_ids.append(produto.id)

      return render(request, 'produto/pesquisa_produto.html', {
         'form': form,
#        'listas': zip(produtos, lista_de_forms),
         'produtos': produtos,
         'lista_de_ids': lista_de_ids,
         'total': total,
         'busca_por': busca_por
      })

   else:
      raise ValueError('Ocorreu um erro inesperado ao tentar pesquisar um produto.')

def exibe_produto(request, id, slug_do_produto):
   produto = get_object_or_404(Produto, id=id)
   return render(request, 'produto/exibe.html', {'produto': produto})

def edita_produtos(request, id):
    produto = get_object_or_404(Produto, id=id)
    form = ProdutoForm(instance=produto)
    form.fields['produto_id'].initial=id
    return render(request, 'produto/cadastra_produto.html', {'form': form})

def pesquisa_produto(request):
    form = PesquisaProdutoForm()
    return render(request, 'produto/pesquisa_produto.html', {
        'form': form
   })

def cadastra_produto(request):
   produto_id = request.POST.get("produto_id", None)
   if request.POST:
      if produto_id:
        produto = get_object_or_404(Produto, id=produto_id)
        form = ProdutoForm(request.POST, instance=produto)  
      else:
        form = ProdutoForm(request.POST)
      
      if form.is_valid():
          produto = form.save(commit=False)
          if produto_id:
              messages.add_message(request, messages.INFO, 'Produto alterado com sucesso')
          else:
              #produto.user = request.user
              messages.add_message(request, messages.INFO, 'Produto cadastrado com sucesso')  
         return redirect('produto:exibe', id=produto.id)
      else:
         messages.add_message(request, messages.ERROR, 'Erro')   
  else:
      form = ProdutoForm()

  fim = datetime.now()   
                            
  ano_fim = fim.year
  mes_fim = fim.month
  dia_fim = fim.day

  inicio = fim - timedelta(days=20)
  ano_inicio = inicio.year
  mes_inicio = inicio.month
  dia_inicio = inicio.day

   return render(request, 'produto/cadastra.html', 
   {'form': form
    'ano_fim': ano_fim, 
    'mes_fim': mes_fim, 
    'dia_fim': dia_fim, 
    'ano_inicio': ano_inicio, 
    'mes_inicio': mes_inicio, 
    'dia_inicio': dia_inicio
   })