from django.urls import path
from . import views

app_name = 'produto'

urlpatterns = [
    path('', views.lista_produtos, name='lista_produtos'),

    path('<slug:slug_da_categoria>/', views.lista_produtos, name='lista_produtos_por_categoria'),

    path('<int:id>/<slug:slug_do_produto>/', views.exibe_produto, name='exibe_produto'),

    path('tamanho/<slug:slug_do_tamanho>/', views.lista_produtos, name='lista_produtos_por_tamanho'),

    path('preco/<slug:slug_do_preco>/', views.lista_produtos, name='lista_produtos_por_preco'),

    path('edita_produto/<int:id>', views.edita_produtos, name='edita_produtos'),

    path('pesquisa_produto/', views.pesquisa_produto, name='lista_produto_pag')
]
