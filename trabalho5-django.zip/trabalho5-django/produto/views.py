from django.shortcuts import render, get_object_or_404
from django.messages import 
from .models import Categoria, Produto, Tamanho, Preco

def lista_produtos(request, slug_da_categoria=None, slug_do_tamanho=None, slug_do_preco=None):
   categoria = None
   tamanho = None
   preco = None
   categorias = Categoria.objects.all().order_by("nome")
   tamanhos = Tamanho.objects.all().order_by("id")
   precos = Preco.objects.all().order_by("id")
   produtos = Produto.objects.filter(disponivel=True).order_by("nome")
   if slug_da_categoria:
      categoria = get_object_or_404(Categoria, slug=slug_da_categoria)
      produtos = produtos.filter(categoria_id=categoria).order_by("nome")

   if slug_do_tamanho: 
      tamanho = get_object_or_404(Tamanho, slug=slug_do_tamanho)
      produtos = produtos.filter(tamanho_id=tamanho).order_by("nome")

   if slug_do_preco:
      preco = get_object_or_404(Preco, slug=slug_do_preco)
      produtos = produtos.filter(preco_id=preco).order_by("nome")

   return render(request, 'produto/lista.html', {'categorias': categorias,
                                                 'tamanhos': tamanhos,
                                                 'precos' : precos,
                                                 'produtos': produtos,
                                                 'categoria': categoria,
                                                 'tamanho': tamanho,
                                                 'preco': preco,
                                                 })

def exibe_produto(request, id, slug_do_produto):
   produto = get_object_or_404(Produto, id=id)
   return render(request, 'produto/exibe.html', {'produto': produto})

def edita_produtos(request, id):
    produto = get_object_or_404(Produto, id=id)
    form = ProdutoForm(instance=produto)
    form.fields['produto_id'].initial=id
    return render(request, 'produto/cadastra_produto.html', {'form': form})

def cadastra_produto(request):
   produto_id = request.POST.get("produto_id", None)
   if request.POST:
      if produto_id:
        produto = get_object_or_404(Produto, id=produto_id)
        form = ProdutoForm(request.POST, instance=produto)  
      else:
        form = ProdutoForm(request.POST)
      
      if form.is_valid():
         produto = form.save()
         if produto_id:
            messages.add_message(request, messages.INFO, 'Produto alterado com sucesso')
         else:
            messages.add_message(request, messages.INFO, 'Produto alterado com sucesso')  
         return redirect('produto:exibe_produto', id=produto.id)
      else:
         messages.add_message(request, messages.ERROR, 'Erro')   
   else:
      form = ProdutoForm()
   
   return render(request, 'produto/cadastra.html', {'form': form})